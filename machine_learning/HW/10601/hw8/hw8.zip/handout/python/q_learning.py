import sys
from mc_environment import MountainCar
from gw_environment import GridWorld

def main(args):
    pass


if __name__ == "__main__":
    main(sys.argv)
